<?php
$con = mysqli_connect("localhost","root","","park");

?>


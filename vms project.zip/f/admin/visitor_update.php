<?php
if (isset($_POST["btnedit"]))
{
    include "connect.php";
    $id = $_POST["id"];
    $vname = $_POST["vname"];
    $idno = $_POST["idno"];
    $rname = $_POST["rname"];
    $dept = $_POST["dept"];
    $mobile = $_POST["mobile"];
    $update = "UPDATE `vistors` SET `visitors-fullname`='$vname',`idno`='$idno',`residents_name`='$rname',`department`='$dept',`mobile`='$mobile' WHERE id = $id";
    $query = mysqli_query($con,$update);
    if ($query){
        echo "<script>
alert('Visitor updated successfully')
window.location = 'visitors_list.php'
</script>";
    }else{
        echo "<script>
alert('failed to update user')
window.location = 'visitors_list.php'
</script>";
    }
}

<?php
echo "<h3>Sending email to clients using php</h3>";
$mailto = "jonathanmthini2@gmail.com";//receiver/clients email address
$subject = "We are developing skills now with jonathan";
$body = "Hi, contact jonathan for more info";
$headers = "From: jonathanmuthini36@gmail.com";
$mail = mail($mailto, $subject ,$body, $headers);
if ($mail)//if all the values in the mail function are correct
{
echo "congratulations, your email send";
}else{
echo "failed";
}


?>


<?php
include "protect.php";
if (isset($_GET["id"]))
{
    include "connect.php";
    $id = $_GET["id"];
    $sql = "DELETE FROM users WHERE id = $id";
    $query = mysqli_query($con,$sql);
    if ($query)
    {
        echo "<script>
alert('User deleted successfully')
window.location = 'users_list.php'
</script>";
    }
    else{
        echo "<script>
alert('No data to delete')
window.location = 'users_list.php'
</script>";
    }
}
?>

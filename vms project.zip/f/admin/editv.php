<?php
include "protect.php";
if (isset($_REQUEST["id"]))
{
    include "connect.php";
    $id = $_REQUEST["id"];
    $select = "SELECT * FROM vistors WHERE id = $id";
    $query = mysqli_query($con,$select);
    if (mysqli_num_rows($query) > 0)
    {
        $list = mysqli_fetch_assoc($query);
    }else
    {
        echo "<script>
alert('sorry! no records found!')
window.location = 'visitors_list.php'
</script>";
    }
}

?>
<?php
include "header.php";
include "nav.php";
?>

<div class="container mt-3 bg-light p-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center text-primary font-weight-bold text-decoration-underline">Edit Visitors Details</div>
                <div class="card-body">
                    <form action="visitor_update.php" method="POST">
                        <input type="hidden" name="id" value="<?= $list ["id"] ?>">
                        <div class="form-group mb-2 append">
                            <label for="" class="font-weight-bold">Visitors fullname:</label>
                            <input type="text" class="form-control" name="vname" value="<?= $list ["visitors-fullname"] ?>">
                        </div>
                        <div class="form-group mb-2 append">
                            <label for="" class="font-weight-bold">Idno:</label>
                            <input type="text" class="form-control" name="idno" value="<?= $list ["idno"] ?>">
                        </div>
                        <p class="text-center text-primary text-decoration-underline text-uppercase my-2">details of whom to meet:</p>
                        <div class="form-group mb-2 append">
                            <label for="" class="font-weight-bold">Residentsname:</label>
                            <input type="text" class="form-control" name="rname" value="<?= $list ["residents_name"] ?>">
                        </div>
                        <div class="mb-2">
                            <label for="" class="font-weight-bold">Department:</label>
                            <input type="text" class="form-control" name="dept" value="<?= $list ["department"] ?>">
                        </div>
                        <div class="form-group mb-2 append">
                            <label for="" class="font-weight-bold">MobileNo:</label>
                            <input type="text" class="form-control" name="mobile" value="<?= $list ["mobile"] ?>">
                        </div>
                        <div class="mb-2">
                            <button type="submit" class="btn btn-success btn-block" name="btnedit">Submit</button>

                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php include "footer.php";?>
<?php
//include "protect.php";
include "header.php";
include "nav.php";
?>
    <br><br>

    <div class="container mt-5 bg-light">
        <h2 class="text-center my-2 text-decoration-underline">Dashboard page</h2>
        <div class="row justify-content-center">
            <div class="col-sm-2 col-xl-3">
                <div class="card bg-primary my-3">
                    <div class="card-header text-white text-center">visitor</div>
                    <div class="card-body">
                        <?php
                        include "connect.php";
                        $sql = "SELECT * FROM `vistors`";
                        $query = mysqli_query($con,$sql);
                        $rows = mysqli_num_rows($query);
                        if ($rows > 0)
                        {
                            echo '<h4 class="mb-3 text-white text-center">'.$rows.'</h4>';
                        }else{
                            echo '<h4 class="mb-4"> 0 </h4>';
                        }
                        ?>
                    </div>
                    <div class="card-footer">
                        <a href="visitors_list.php" class="text-light text-center"><center>visitors list</center></a>
                    </div>
                </div>

            </div>
            <div class="col-sm-2 col-xl-3">
                <div class="card bg-warning my-3">
                    <div class="card-header text-white text-center">Users</div>
                    <div class="card-body">
                        <?php
                        include "connect.php";
                        $sql = "SELECT * FROM `users`";
                        $query = mysqli_query($con,$sql);
                        $rows = mysqli_num_rows($query);
                        if ($rows > 0)
                        {
                            echo '<h4 class="mb-3 text-white text-center">'.$rows.'</h4>';
                        }else{
                            echo '<h4 class="mb-4"> 0 </h4>';
                        }
                        ?>
                    </div>
                    <div class="card-footer">
                        <a href="users_list.php" class="text-light text-center"><center>users list</center></a>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php include "footer.php";




<?php
session_start();
if (! isset($_SESSION["logged_in"]))
{
    echo "<script>
alert('sorry!, you need to login first to access this page')
window.location='login.php'
</script>";
}
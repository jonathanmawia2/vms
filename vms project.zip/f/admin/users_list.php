<?php
include "protect.php";
include "connect.php";
$select = "SELECT * FROM `users`";
$query_run = mysqli_query($con,$select);
if (mysqli_num_rows($query_run) > 0)
{
    $users = mysqli_fetch_all($query_run, 1);
}else
{
    echo "<script>
alert('no records found')
window.location = 'users_list.php'
</script>";
}
?>


<?php
include "header.php";
include "nav.php";

?>
    <br><br>
    <div class="container mt-5 bg-light">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card my-4">
                    <div class="card-header">
                        <h4 class="text-uppercase text-center text-decoration-underline">list of users</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                            <tr>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($users as $list): ?>
                            <tr>
                                <td><?= $list["username"] ?></td>
                                <td><?= $list["email"] ?></td>
                                <td class="text-center">
                                    <a href="edit_user.php?id=<?= $list["id"] ?>" title="edit visitor" class="text-primary mr-2"><i class="fa fa-pencil"></i></a>
                                    <a href="view_user.php?id=<?= $list["id"] ?>" title="view visitor" class="text-success mr-2"><i class="fa fa-eye"></i></a>
                                    <a href="delete_user.php?id=<?= $list["id"] ?>" title="delete visitor"class="text-danger"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include "footer.php";





<?php
include "protect.php";
include "connect.php";
if (isset($_GET["id"]))
{
    $id = $_GET["id"];
    $sql = "DELETE FROM vistors WHERE id = $id";
    $query = mysqli_query($con,$sql);
    if ($query)
    {
        echo "<script>
alert('User deleted successfully')
window.location = 'visitors_list.php'
</script>";
    }
    else{
        echo "<script>
alert('No data to delete')
window.location = 'visitors_list.php'
</script>";
    }
}
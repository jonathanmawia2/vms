<?php
session_start();
include "connect.php";
include "header.php";
include "nav.php";

if (isset($_POST["changepwd"]))
{
    $id = $_SESSION['id'];
    $oldpwd = $_POST["oldpwd"];
    $newpwd = $_POST["newpwd"];
    $rnew = $_POST["rnewpwd"];

    $sql = "SELECT FROM `users` WHERE id = $id";
    $query = mysqli_query($con,$sql);
    if (mysqli_num_rows($query) > 0)
    {
        $pswd = mysqli_fetch_assoc($query);
        $hash = $pswd["password"];
        if (password_verify($hash,$oldpwd))
        {
        $sql = "UPDATE `users` SET password = '$newpwd' WHERE id = $id";
        $query1 = mysqli_query($con,$sql);
        if ($query1)
        {
           echo "<script>
alert('updated')
window.location = 'login.php'
</script>";
        }else
        {
            echo "<script>
alert('failed to update')
window.location = 'changepassword.php'
</script>";
        }
        }else{
            echo "<script>
alert('failed! wrong password')
window.location = 'changepassword.php'
</script>";
        }
    }


}
?>
<div class="container mt-5">
    <br><br><br>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center">Change password!</div>
                <div class="card-body">
                        <form action="changepassword.php" method="POST">
                            <input type="hidden" name="id">
                            <div class="mb-2 form-group">
                                <label for="">Enter old Password</label>
                                <input type="text" placeholder="enter old password" name="oldpwd" value="<?= $pswd['password']; ?>" class="form-control">
                            </div>
                            <div class="mb-2 form-group">
                                <label for="">Enter New Password</label>
                                <input type="text" placeholder="enter old password" name="newpwd" class="form-control">
                            </div>
                            <div class="mb-2 form-group">
                                <label for="">Repeat New Password</label>
                                <input type="text" placeholder="enter old password" name="rnewpwd" class="form-control">
                            </div>
                            <div class="mb-2 form-group">
                                <button class="btn btn-success btn-block" name="changepwd">save changes</button>
                            </div>
                        </form>

                </div>
            </div>
        </div>
    </div>
</div>

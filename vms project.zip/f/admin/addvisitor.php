<?php
//ini_set("display_errors",1);
//error_reporting(E_ALL);
include "protect.php";
include "connect.php";
if (isset($_POST['submit']))
{
    //function to send sms
    $phoneNumber = $_POST["phone"];
    $vname = trim($_POST["vname"]);
    $company = "Jitahidi";
    $message = "Hello " .$vname." welcome to ".$company. " and your OTP is : " .rand(1000,10000). " please do not share it with any one!";
    function sendSms($phoneNumber, $message)
    {
        $apiKey = "	b81c6ccb9dba93bb4fd63e37597e8ed811b829ec15f3e811442fe08189391c2b";
        $sendeName = "23107";

        $bodyRequest = array(
            "mobile" => $phoneNumber,
            "response_type" => "json",
            "sender_name" => $sendeName,
            "service_id" => 0,
            "message" => $message
        );
        $payload = json_encode($bodyRequest);
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.mobitechtechnologies.com/sms/sendsms',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => array(
                'h_api_key: ' . $apiKey,
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
    }

    //function to send sms end here!

    $vname = trim($_POST["vname"]);
    $idno = trim($_POST["idno"]);
    $phoneNumber = $_POST["phone"];
    $gender = trim($_POST["gender"]);
    $rname = trim($_POST["rname"]);
    $department = trim($_POST["department"]);
    $mobile = trim($_POST["mobile"]);
    $target_dir = "uploads/";
    $target_file = $target_dir . rand(10, 100) . "_" . basename($_FILES["photo"]["name"]);
    $file_extension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));//png jpg

    if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
//echo "Uploaded";
        $upload_status = true;
    }
    if (empty($vname) || empty($idno) || empty($gender) || empty($rname) || empty($department) || empty($mobile) || empty($target_file)) {
        echo "<script>
       alert('sorry! a field is reqired')
       window.location='navigation.php'
       </script>";
    } elseif (strlen($mobile) != 10) {
        echo "<script>
       alert('sorry! mobile number should have 10 characters')
       window.location='navigation.php'
       </script>";
    } else {
        $sql = "INSERT INTO `vistors`(`visitors-fullname`, `idno`,`phone`, `gender`, `photo`, `residents_name`, `department`, `mobile`) VALUES ('$vname','$idno','$phoneNumber','$gender','$target_file','$rname','$department','$mobile')";
        $query = mysqli_query($con, $sql);
        if ($query) {
            echo "<script>
       alert('woow! data inserted successfully')
       window.location='visitors_list.php'
       </script>";
            sendSms($phoneNumber, $message);

        }
    }
}
?>
<?php
include "header.php";
include "nav.php";
?>
    <br>
    <div class="container mt-5 bg-light">
        <div class="row justify-content-center">
            <div class="col-md-7">
                                    <div class="card shadow my-4">
                                        <div class="card-header text-center text-primary">Add Visitor</div>
                                        <div class="card-body">
                                            <form action="addvisitor.php" method="POST" enctype="multipart/form-data">
                                                <div class="form-group mb-2 append">
                                                    <label for="" class="font-weight-bold">Visitors fullname:</label>
                                                    <input type="text" class="form-control" name="vname"
                                                           placeholder="enter your visitors name" autocomplete="off">
                                                </div>
                                                <div class="form-group mb-2 append">
                                                    <label for="" class="font-weight-bold">Visitors phonenumber:</label>
                                                    <input type="text" class="form-control" name="phone"
                                                           placeholder="enter your visitors name" autocomplete="off">
                                                </div>
                                                <div class="form-group mb-2 append">
                                                    <label for="" class="font-weight-bold">Idno:</label>
                                                    <input type="number" class="form-control" name="idno" placeholder="enter your idno" autocomplete="off">
                                                </div>
                                                <div class="form-group mb-2 append">
                                                    <label for="" class="font-weight-bold">Gender:</label>
                                                    <input type="radio" name="gender" value="male">male
                                                    <input type="radio" name="gender" value="female">female
                                                </div>

                                                <div class="form-group mb-2 append">
                                                    <label for="" class="font-weight-bold">Photo:</label>
                                                    <input type="file" class="form-control" name="photo">
                                                </div>
                                                <br>
                                                <p class="text-center text-primary text-decoration-underline text-uppercase">details of
                                                    whom to meet:</p>
                                                <div class="form-group mb-2 append">
                                                    <label for="" class="font-weight-bold">Residentsname:</label>
                                                    <input type="text" class="form-control" name="rname"
                                                           placeholder="enter residents name" autocomplete="off">
                                                </div>
                                                <div class="mb-2">
                                                    <label class="text-dark"><strong>Department:</strong></label>
                                                    <select class="form-select" name="department">
                                                        <option value="space">choose department</option>
                                                        <option value="finance">Finance</option>
                                                        <option value="hrm">HRM</option>
                                                        <option value="ict">ICT</option>
                                                        <option value="Records">Records</option>
                                                        <option value="packaging">Packaging</option>
                                                    </select>
                                                </div>
                                                <div class="form-group mb-2 append">
                                                    <label for="" class="font-weight-bold">MobileNo:</label>
                                                    <input type="number" class="form-control" name="mobile"
                                                           placeholder="enter residents mobile number" autocomplete="off">
                                                </div>
                                                <div class="mb-2">
                                                    <button type="submit" class="btn btn-success pull-right" name="submit">Submit
                                                    </button>
                                                    <button type="reset" class="btn btn-danger pull-right mr-2" name="reset">Clear
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
            </div>
        </div>
    </div>
<?php include "footer.php";






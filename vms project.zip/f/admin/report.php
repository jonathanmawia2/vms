<?php
include "header.php";
include "nav.php";
?>
    <br><br><br>
<div class="container mt-3 bg-light">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <p>This is a general report</p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab aliquam consequatur cupiditate dignissimos dolor et eveniet explicabo ipsum, necessitatibus nulla quaerat quasi quos sit? Amet magnam maiores mollitia possimus quibusdam.
        </div>
    </div>
</div>
<?php include "footer.php";


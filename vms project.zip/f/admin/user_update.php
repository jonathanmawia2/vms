<?php
include "connect.php";
if (isset($_POST["btn"]))
{
    $id = $_POST["id"];
    $username = $_POST["username"];
    $email = $_POST["email"];
    $update = "UPDATE `users` SET `username`='$username',`email`='$email' WHERE id = $id";
    $query_update = mysqli_query($con,$update);
    if ($query_update){
        echo "<script>
alert('User updated successfully')
window.location = 'users_list.php'
</script>";
    }else{
        echo "<script>
alert('failed to update user')
window.location = 'users_list.php'
</script>";
    }
}

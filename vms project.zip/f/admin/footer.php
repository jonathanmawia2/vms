<?php?>
<footer class="main-footer bg-info fixed-bottom py-2 text-center">
    Copyright &copy; <?php echo date("Y");?> <strong><span class="text-white text-center">Company Visitor Management System</span>  </strong>
    <script src="../includes/popper.min.js"></script>
    <script src="../includes/bootstrap.min.js"></script>
    <script src="../includes/datatables.min.js"></script>
    <script src="../includes/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function(){
            $('table').DataTable();
        });
    </script>
    </body>
    </html>

</footer>

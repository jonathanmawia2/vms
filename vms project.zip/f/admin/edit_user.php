<?php
include "protect.php";
if (isset($_REQUEST["id"]))
{
    include "connect.php";
    $id = $_REQUEST["id"];
    $select = "SELECT * FROM users WHERE id = $id";
    $query = mysqli_query($con,$select);
    if (mysqli_num_rows($query) > 0)
    {
        $users = mysqli_fetch_assoc($query);
    }else{
        echo "<script>
alert('sorry! no data found in the database')
</script>";
    }
}

?>
<?php
include "header.php";
include "nav.php";
?>

<div class="container mt-3 bg-light p-4">
    <div class="row justify-content-center">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-header text-decoration-underline text-primary text-center text-uppercase font-weight-bold">Edit Users details</div>
                <div class="card-body">
                    <form action="user_update.php" method="POST" class="form-control shadow">
                        <input type="hidden" name="id" value="<?= $users ["id"] ?>">
                        <div class="form-group mb-2 append">
                            <label for="" class="font-weight-bold">Username:</label>
                            <input type="text" class="form-control" name="username" value="<?= $users ["username"] ?>">
                        </div>
                        <div class="form-group mb-2 append">
                            <label for="" class="font-weight-bold">Email:</label>
                            <input type="text" class="form-control" name="email" value="<?= $users ["email"] ?>">
                        </div>
                        <div class="form-group mb-2 append">
                            <button class="btn btn-success btn-block" name="btn">Update</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php include "footer.php";?>

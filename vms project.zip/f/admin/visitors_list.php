<?php
include "protect.php";
ini_set("display_errors", "1");
error_reporting(E_ALL);
include "connect.php";
$select = "SELECT * FROM `vistors`";
$list = mysqli_query($con, $select);
if (mysqli_num_rows($list) > 0) {
    $rows = mysqli_fetch_all($list, 1);
} else {
    echo "<script>
    alert('sorry! no data fond in the database')
    window.location='visitors_list.php'
    </script>";
}
?>

<?php
include "header.php";
include "nav.php";
?>
    <br><br>
    <div class="container mt-3 bg-light p-4">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card my-4">
                    <div class="card-header">
                        <h4 class="text-uppercase text-center text-decoration-underline text-info">list of visitors</h4>
                    </div>
                    <div class="card-body">

                        <table class="table table-bordered table-striped" id="dt">
                            <thead>
                            <tr>
                                <th>Photo</th>
                                <th>vistors-name</th>
                                <th>idno</th>
                                <th>gender</th>
                                <th>time-in</th>
                                <th>residents-name</th>
                                <th>department</th>
                                <th>mobile</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($rows as $visitor): ?>
                                <tr>
                                    <td><img src="<?= $visitor["photo"] ?>" style="height: 50px; width: 50px"></td>
                                    <td><?= $visitor["visitors-fullname"] ?></td>
                                    <td><?= $visitor["idno"] ?></td>
                                    <td><?= $visitor["gender"] ?></td>
                                    <td><?= $visitor["time_in"] ?></td>
                                    <td><?= $visitor["residents_name"] ?></td>
                                    <td><?= $visitor["department"] ?></td>
                                    <td><?= $visitor["mobile"] ?></td>
                                    <td class="text-center">
                                        <a href="editv.php?id=<?= $visitor["id"] ?>" title="edit visitor" class="text-primary mr-2"><i class="fa fa-pencil"></i></a>
                                        <a href="viewvisitor.php?id=<?= $visitor["id"] ?>" title="view visitor" class="text-success mr-2"><i class="fa fa-eye"></i></a>
                                        <a href="deletevisitor.php?id=<?= $visitor["id"] ?>" title="delete visitor" class="text-danger"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include "footer.php";



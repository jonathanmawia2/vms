<?php
include "protect.php";
if (isset($_REQUEST["id"]))
{
    include "connect.php";
    $id = $_REQUEST["id"];
    $select = "SELECT * FROM users WHERE id = $id";
    $query = mysqli_query($con,$select);
    if (mysqli_num_rows($query) > 0)
    {
        $users = mysqli_fetch_assoc($query);
    }else{
        echo "<script>
alert('sorry! no data found in the database')
</script>";
    }
}

?>
<?php
include "header.php";
include "nav.php";
?>
<br><br>
<div class="container mt-5 bg-light p-4">
    <div class="row justify-content-center">
        <div class="col-sm-6">
            <div class="mb-2 text-info text-center bg-white"><h3 >View User Details </h3></div>
            <hr>

            <form action="user_update.php" method="POST" class="form-control shadow">
                <div class="form-group mb-2 append">
                    <p class="text-center my-3"><span class="font-weight-bold">Username: &nbsp;</span><?= $users ["username"] ?></p>
                </div>
                <div class="form-group mb-2 append">
                    <p class="text-center my-3"><span class="font-weight-bold">Email: &nbsp;</span><?= $users ["email"] ?></p>
                </div>

            </form>

        </div>
    </div>
</div>
<?php include "footer.php";?>

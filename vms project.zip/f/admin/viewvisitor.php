
<?php
include "protect.php";
if (isset($_REQUEST["id"]))
{
    include "connect.php";
    $id = $_REQUEST["id"];
    $select = "SELECT * FROM vistors WHERE id = $id";
    $query = mysqli_query($con,$select);
    if (mysqli_num_rows($query) > 0)
    {
        $list = mysqli_fetch_assoc($query);
    }else
    {
        echo "<script>
alert('sorry! no records found!')
window.location = 'visitors_list.php'
</script>";
    }
}

?>
<?php
include "header.php";
include "nav.php";
?>
<br>
    <div class="container mt-5 bg-light p-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="mb-2 text-info text-center bg-white"><h3 >View Visitor Details </h3></div>
                <hr>
                <form action="visitor_update.php" method="POST" class="form-control shadow">
                    <div class="form-group mb-2 append">
                        <p class="text-center my-2"><img class="rounded" src="<?= $list ["photo"] ?>" style="height: 70px; width: 70px; border-radius: 50%"><br><span class="font-weight-bold">Visitors photo: &nbsp;</span></p>
                    </div>
                    <div class="form-group mb-2 append">
                        <p class="text-center my-3"><span class="font-weight-bold">Visitors fullname: &nbsp;</span><?= $list ["visitors-fullname"] ?></p>
                    </div>
                    <div class="form-group mb-2 append">
                        <p class="text-center my-3"><span class="font-weight-bold">Visitors idno: &nbsp;</span><?= $list ["idno"] ?></p>
                    </div>
                    <div class="form-group mb-2 append">
                        <p class="text-center my-3"><span class="font-weight-bold">Time_in: &nbsp;</span><?= $list ["time_in"] ?></p>
                    </div>
                    <div class="form-group mb-2 append">
                        <p class="text-center my-3"><span class="font-weight-bold">Gender: &nbsp;</span><?= $list ["gender"] ?></p>
                    </div>
                    <hr>
                    <p class="text-center text-primary text-decoration-underline text-uppercase my-2">details of whom to meet:</p>
                    <hr>
                    <div class="form-group mb-2 append">
                        <p class="text-center my-3"><span class="font-weight-bold">Residents name: &nbsp;</span><?= $list ["residents_name"] ?></p>
                    </div>
                    <div class="mb-2">
                        <p class="text-center my-3"><span class="font-weight-bold">Department: &nbsp;</span><?= $list ["department"] ?></p>
                    </div>
                    <div class="form-group mb-2 append">
                        <p class="text-center my-3"><span class="font-weight-bold">Residents mobile: &nbsp;</span><?= $list ["mobile"] ?></p>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php include "footer.php";?>
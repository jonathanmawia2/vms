<?php
include "header.php";
include "nav.php";
if (isset($_POST["email"])) {

    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    //retrive one record that matches that email.(only one email should match)
    //check the password hash(encrypted password in our database
   //if the above steps are ok, you need to storedata in a session.
    require 'connect.php';
    $query = mysqli_prepare($con, "SELECT * FROM `users` WHERE email = ?"); //this lines are used to prevent mysqli injection.
    mysqli_stmt_bind_param($query, "s", $email);
    mysqli_stmt_execute($query);//same as(mysqli_query).//execute the query
    $result = mysqli_stmt_get_result($query);
    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
//        var_dump($user);
//        die();
        $hash = $user["password"];
        if (password_verify($password,$hash))
        {
            session_start();
            $_SESSION["username"] = $user["username"];
            $_SESSION["id"] = $user["id"];
            $_SESSION["logged_in"] = true;
            ?>
            <script>
                Swal.fire({
                    title:'Success',
                    icon:'success',
                    text:'login success',
                    button:'success'

                });
                window.location='index.php'
            </script>
            <?php
        }else{
         ?>
          <script>
              Swal.fire(
                  'Failed!',
                  'You entered wrong password!',
                  'error'

              )
                window.location='login.php'
            </script>
          <?php

        }
    } else {
        ?>
        <script>
            Swal.fire({
                title:'Failed',
                icon:'error',
                text:'No data found!',
                button:'error',
                timer:1500
            })
            window.location='login.php'
        </script>
        <?php
    }

}
?>

<?php
?>
<br><br><br>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-sm-5">
            <div class="card">
                <div class="card-header text-center font-weight-bold text-decoration-underline"><h4>Login page</h4></div>
                <div class="card-body">

                    <form action="login.php" method="POST">
                        <div class="mb-2 form-group">
                            <label for="">Email</label>
                            <input type="email" name="email" placeholder="enter email" class="form-control">
                        </div>
                        <div class="mb-2 form-group">
                            <label for="">Password</label>
                            <input type="password" name="password" placeholder="enter password" class="form-control">
                        </div>
                        <div class="mb-2">
                            <button type="submit" name="btnlogin" class="btn btn-success btn-block">login</button>

                        </div>
                        <div class="mb-2">
                            <label for="">Remember Me</label> <input type="checkbox" checked class="pl-2">&nbsp;&nbsp;&nbsp;&nbsp;<span class="pull-right ml-5"><a
                                    href="resetpassword.php">forgotten password?</a></span>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>


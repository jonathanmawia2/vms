<?php
session_start();
ini_set("display_errors",1);
error_reporting(E_ALL);
if (isset($_POST["btn"])) {
    $phoneNumber = $_POST["phone"];
    $message = "This is a code";
    function sendSms($phoneNumber, $message)
    {
        $apiKey = "	b81c6ccb9dba93bb4fd63e37597e8ed811b829ec15f3e811442fe08189391c2b";
        $sendeName = "23107";

        $bodyRequest = array(
            "mobile" => $phoneNumber,
            "response_type" => "json",
            "sender_name" => $sendeName,
            "service_id" => 0,
            "message" => $message
        );
        $payload = json_encode($bodyRequest);
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.mobitechtechnologies.com/sms/sendsms',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => array(
                'h_api_key: ' . $apiKey,
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        if ($response)
        {
            $_SESSION["status"] = "please wait for a message from your phone!";
        }else{
            $_SESSION["status"] = "error has occured".curl_error($curl);
        }

    }

    sendSms($phoneNumber, $message);
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../includes/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <?php
            if (isset($_SESSION["status"]))
            {
                ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <strong>Success!</strong> <?php echo $_SESSION['status']; ?>
                </div>
            <?php
                unset($_SESSION['status']);
            }
            ?>
            <div class="card">
                <div class="card-header">Sending single sms </div>
                <div class="card-body">
                    <form action="sms.php" method="POST">
                        <div class="mb-2">
                            <label for="">Phone Number</label>
                            <input type="text" placeholder="phone" name="phone" class="form-control">
                        </div>
                        <div class="mb-2">
                            <button class="btn btn-success btn-block" name="btn">Send Sms</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>


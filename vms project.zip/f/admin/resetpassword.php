<?php
session_start();
include "connect.php";

//function to send mail.
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';
function  send_password_reset($get_username,$get_email,$token)
{

}

if (isset($_POST["resetpwd"]))
{
    $email = mysqli_real_escape_string($con,$_POST["email"]);
    //lets generate a token.
    $token = md5(rand());
    $check_email = "SELECT email FROM `users` WHERE email = '$email' LIMIT 1";
    $query = mysqli_query($con,$check_email);

    if (mysqli_num_rows($query) > 0)
    {
   $row = mysqli_fetch_array($query);
   $get_username = $row["username"];
   $get_email = $row["email"];
   //verify token in the database.
        $update_token = "UPDATE `users` SET verify_token = '$token' WHERE email = '$get_email' LIMIT 1";
        $update_query = mysqli_query($con,$update_token);
        if ($update_query)
        {
       //if the token is updated, the we need to send the mail now,
            send_password_reset($get_username,$get_email,$token);
            $_SESSION["status"] = "We emailed you password reset link";
            header("location:resetpassword.php");
            exit(0);

        }else{
            $_SESSION["status"] = "Something went wrong!. #1";
            header("location:resetpassword.php");
            exit(0);
        }
    }else{
        $_SESSION["status"] = "no email found";
        header("location:resetpassword.php");
        exit(0);
    }
}


?>

<?php
include "header.php";
include "nav.php";
?>
<br><br><br>
<div class="container mt-5 bg-light">
    <div class="row justify-content-center">
        <div class="col-sm-6">
            <div class="card my-4">
                <div class="card-header text-center font-weight-bold">password reset</div>
                <div class="card-body">
                    <form action="resetpassword.php" method="POST">
                        <div class="mb-3">
                            <label for="">Email</label>
                            <input type="email" class="form-control" name="email" placeholder="enter email">
                        </div>
                        <div class="mb-3">
                            <button class="btn btn-primary btn-block" name="resetpwd">send reset link</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


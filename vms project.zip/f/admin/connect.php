<?php
$con = mysqli_connect("localhost","root","","vms") or die("failed!".mysqli_connect_error($con));


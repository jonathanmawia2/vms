<?php
include "protect.php";
include "connect.php";
if (isset($_POST["btnuser"]))
{
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $password = password_hash($password,PASSWORD_BCRYPT);
    $token = md5(rand());


    if (empty($username) || empty($email) || empty($password))
    {
        echo "<script>
        alert('sorry! a field is required')
        window.location='users_list.php'
        </script>";
    }
    elseif (!filter_var($email,FILTER_VALIDATE_EMAIL))
    {
        echo "<script>
        alert('sorry! please enter a valid email')
        window.location='navigation.php'
        </script>";
    }
    else
    {
        $sql = "INSERT INTO `users`(`username`, `email`, `password`,`verify_token`) VALUES ('$username','$email','$password','$token')";
        $user = mysqli_query($con,$sql);
        if($user)
        {
            echo "<script>
        alert('woow! data inserted successfully')
        window.location='users_list.php'
        </script>";
        }else
        {
            echo "<script>
        alert('sorry! failed')
        window.location='navigation.php'
        </script>";
        }
    }
}
?>

<?php
include "header.php";
include "nav.php";

?>
<div class="container mt-3 bg-light">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow my-3">
                <div class="card-header">Add user</div>
                <div class="card-body">
                    <form action="adduser.php" method="POST">
                                <div class="form-group mb-2">
                                    <label for="" class="font-weight-bold">Username:</label>
                                    <input type="text" class="form-control" name="username"
                                           placeholder="enter your username" autocomplete="off">
                                </div>
                                <div class="form-group mb-2">
                                    <label for="" class="font-weight-bold">Email:</label>
                                    <input type="text" class="form-control" name="email" placeholder="enter your email">
                                </div>
                                <div class="form-group mb-2 append">
                                    <label for="" class="font-weight-bold">Password:</label>
                                    <input type="password" class="form-control" name="password" placeholder="enter your password">
                                </div>
                                <div class="mb-2">
                                    <button type="submit" data-loading-text="Loading..."  class="btn btn-success pull-right" name="btnuser">Submit</button>
                                    <button type="reset" class="btn btn-danger pull-right mr-2" name="reset">Clear</button>
                                </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>




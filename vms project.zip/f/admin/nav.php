

<?php
session_start();
?>
<?php?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="includes/bootstrap.min.css">
    <link rel="stylesheet" href="includes/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">


</head>
<body style="background: lavenderblush;">


<nav class="navbar navbar-expand-sm bg-info navbar-light fixed-top shadow">
    <!-- Brand -->
    <a class="navbar-brand ml-3" href="#">Logo</a>
    <a class="navbar-brand ml-5 bg-light text-dark p-1 rounded" href="#"><?php echo date("D d-m-Y H:i:s:t"); ?></a>
    <!-- Links -->
    <ul class="navbar-nav pr-3 ml-auto">
<?php if (isset($_SESSION["logged_in"])): ?>
            <li class="nav-item list-unstyled">
                <a class="nav-link active border showing text-white" href="about.php"><i class="fa fa-info"></i>&nbsp;&nbsp;About VMS</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-white" href="index.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="report.php"><i class="fa fa-file"></i>&nbsp;&nbsp;general report</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-white" href="#" id="navbardrop" data-toggle="dropdown">
                    <i class="fa fa-user"></i>&nbsp;&nbsp;Visitors
                </a>
                <div class="dropdown-menu pr-5">
                    <a class="dropdown-item" href="addvisitor.php"><i class="fa fa-user-plus"></i>&nbsp;&nbsp;Add visitor</a>
                    <a class="dropdown-item" href="visitors_list.php"><i class="fa fa-list"></i>&nbsp;&nbsp;Visitors list</a>
                </div>
            </li>


            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-white" href="#" id="navbardrop" data-toggle="dropdown">
                    <i class="fa fa-user"></i>&nbsp;&nbsp;User
                </a>
                <div class="dropdown-menu pr-5">
                    <a class="dropdown-item" href="adduser.php"><i class="fa fa-user-plus"></i>&nbsp;&nbsp;Add user</a>
                    <a class="dropdown-item" href="users_list.php"><i class="fa fa-list"></i>&nbsp;&nbsp;User list</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-white" href="#" id="navbardrop" data-toggle="dropdown">
                    contact us
                </a>
                <div class="dropdown-menu pr-5">
                    <a class="dropdown-item" href="#"><i class="fa fa-envelope"></i>&nbsp;&nbsp;sms</a>
                    <a class="dropdown-item" href="#"><i class="fa fa-envelope-open-o"></i>&nbsp;&nbsp;email</a>
                    <a class="dropdown-item" href="#"><i class="fa fa-phone-square"></i>&nbsp;&nbsp;phone call</a>
                </div>
            </li>

            <!-- Dropdown -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                    <img class="pr-2" src="uploads/avatar.png" alt="" style="height: 20px; width: 25px"><?= $_SESSION["username"]; ?>
                </a>
                <div class="dropdown-menu dropdown-menu-sm-right pr-2">
                    <a class="dropdown-item" href="#"><i class="fa fa-user"></i>&nbsp;&nbsp;Profile</a>
                    <a class="dropdown-item" href="changepassword.php?id=<?= $_SESSION["id"] ?>"><i class="fa fa-pencil-square"></i>&nbsp;&nbsp;change password</a>
                    <a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out"></i>Logout</a>
                </div>
            </li>
        <?php endif; ?>
        <?php if (! isset($_SESSION["logged_in"])): ?>
                <li class="nav-item mr-5">
                    <button class="btn btn-light btn-sm"><a class="nav-link text-dark" href="login.php"><i class="fa fa-sign-in"></i>&nbsp;&nbsp;Login</a></button>
                </li>
        <?php endif; ?>
    </ul>
</nav>
</body>
</html>

